# Abgabe

Abgabe von Patrick Hübler für KI-2 Internettechnologien

Matrikelnummer: 22202466

# Link to Github

https://github.com/Patrick2052/thd-chatbot-abgabe
