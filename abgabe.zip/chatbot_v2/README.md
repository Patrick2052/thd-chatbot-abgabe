# Run

create a python venv and install the requirements

then run server.py to start the application